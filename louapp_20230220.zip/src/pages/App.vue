<template>
<div class="container">
  <router-view />
</div>
</template>
<style>
html,body{
  background-color:whitesmoke;
}
#lou {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  width:100%;
  height:100%;
  padding:10px 0;
  background-color:whitesmoke;
}
.area{
  background-color:whitesmoke;
}
h1,h2,h3,h4,h5,h6{padding:0;margin:0;}
ul,li{
  list-style: none;
}
</style>
